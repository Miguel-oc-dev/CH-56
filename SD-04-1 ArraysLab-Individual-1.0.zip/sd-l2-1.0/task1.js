const arr = []

// Type your code below this line!



// Type your code above this line!

arr.forEach(element => console.log(element))