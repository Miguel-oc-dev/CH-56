const arr = [16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1]

// Type your code below this line!



// Type your code above this line!

arr.forEach(element => console.log(element))