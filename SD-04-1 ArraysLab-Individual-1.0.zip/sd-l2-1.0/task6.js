const arr1 = ["hello"]
const arr2 = ["world"]

// Type your code below this line!



// Type your code above this line!