// Refer to Task 3 in your Instructions to complete this task

for (let i = 0; i < 1; i++) {
    console.log("This is Task Three!");
  };